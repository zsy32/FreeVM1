# -*- coding: utf-8 -*-

import bayesian_changepoint_detection.online_changepoint_detection as oncd
from functools import partial
import numpy as np

#
def is_change_point(data, prior_step, thresh):
    R, maxes = oncd.online_changepoint_detection(data, partial(oncd.constant_hazard, 250), oncd.StudentT(0.1, 0.01, 1, 0))
    cpp = R[prior_step, -prior_step-1:-1]
    # cpp = R[prior_step, prior_step+1:-1]
    if max(cpp) >= thresh:
        # print cpp
        return True
    else:
        return False


def k_sigma(data, k):

    return np.mean(data) - k * np.std(data)


def ewma(data, alpha):

    result = 0
    for i in range(len(data)):
        result += alpha*pow(1-alpha, len(data)-1-i)*data[i]
    return result

if __name__ == "__main__":
    data = [0,1,0,1,0,1]
    print(k_sigma(data, 1))
